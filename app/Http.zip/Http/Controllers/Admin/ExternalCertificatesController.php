<?php

namespace App\Http\Controllers\Admin;

use App\ExternalCertificate;
use App\Http\Requests;
use App\Http\Controllers\Controller;


use App\V2\Model\CountryTable;
use Illuminate\Http\Request;

class ExternalCertificatesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $this->authorize('access','view_external_certificates');
        $keyword = $request->get('filter');
        $perPage = 25;

        /*if (!empty($keyword)) {
            $external_certificates = ExternalCertificate::whereRaw("match(title,content,slug) against (? IN NATURAL LANGUAGE MODE)", [$keyword])->paginate($perPage);
        } else {
            $external_certificates = ExternalCertificate::latest()->paginate($perPage);
        }*/

        $external_certificates = ExternalCertificate::latest()->paginate($perPage);

        return view('admin.external_certificates.index', compact('external_certificates','perPage'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $this->authorize('access','add_external_certificate');
	    $countryTable = new CountryTable();
	    $countries = $countryTable->getRecords();
        //return view('admin.external_certificates.create',$countries);
	    $output['countries'] = $countries;
	    return view('admin.external_certificates.create',$output);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $this->authorize('access','add_external_certificate');
        $this->validate($request,[
            'title'=>'required'
        ]);

        $requestData = $request->all();
        $external_certificate = ExternalCertificate::create($requestData);

        return redirect('admin/external_certificates')->with('flash_message', __('default.changes-saved'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $this->authorize('access','view_external_certificates');
        $external_certificate = ExternalCertificate::findOrFail($id);

        return view('admin.external_certificates.show', compact('external_certificate'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $this->authorize('access','edit_external_certificate');
        $external_certificate = ExternalCertificate::findOrFail($id);
	
	    $countryTable = new CountryTable();
	    $countries = $countryTable->getRecords();

		
        return view('admin.external_certificates.edit', compact('external_certificate','countries'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        $this->authorize('access','edit_external_certificate');
        $this->validate($request,[
            'title'=>'required'
        ]);

        $requestData = $request->all();

        $external_certificate = ExternalCertificate::findOrFail($id);
        $external_certificate->update($requestData);

        return redirect('admin/external_certificates')->with('flash_message', __('default.changes-saved'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $this->authorize('access','delete_external_certificate');
        ExternalCertificate::destroy($id);

        return redirect('admin/external_certificates')->with('flash_message', __('default.record-deleted'));
    }
}
